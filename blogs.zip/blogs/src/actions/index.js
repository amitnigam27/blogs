import jsonPlaceholder from '../apis/jsonPlaceholder';

//RETURN A FUNCTION
export const fetchPosts = () => async dispatch => {
    const response = await jsonPlaceholder.get('/posts');

    dispatch({ type: 'FETCH_POSTS', payload: response })
};


//TOTALLY FINE!
//NORMALLY
// export const selectPost = () => {
//     return {
//         type: 'SELECT_POST'
//     };
// };