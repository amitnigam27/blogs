import React from 'react';

class PostList extends React.Component{
    render(){
        return <div>Post list</div>;
    }
};

export default PostList;
